@echo off
echo This came from the SECOND (hidden) ZIP.
echo A tool that only reads the first ZIP never saw this file.
pause
